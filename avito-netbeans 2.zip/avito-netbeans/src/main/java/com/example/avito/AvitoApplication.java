package com.example.avito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvitoApplication {
    public static void main(String[] args) {
        SpringApplication.run(AvitoApplication.class, args);
    }
}
